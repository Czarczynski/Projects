## 0.0.1+6

* Make the pedantic dev_dependency explicit.

## 0.0.1+5

* Fix readme

## 0.0.1+4

* Bump gradle version to avoid bugs with android projects

## 0.0.1+3

* Update README.

## 0.0.1+2

* Remove unused onMethodCall method.

## 0.0.1+1

* Add an android/ folder with no-op implementation to workaround https://github.com/flutter/flutter/issues/46898.

## 0.0.1

* Initial open source release.
